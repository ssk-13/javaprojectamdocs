package daoInterface;
import java.util.List;

import entity.Technician;

public interface TechnicianDAO {
    int addTechnician(Technician technician);
    int updateTechnician(Technician technician);
    int deleteTechnician(int technicianId);
    Technician getTechnicianById(int technicianId);
    List<Technician> getAllTechnicians();
}
