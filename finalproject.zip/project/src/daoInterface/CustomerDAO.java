package daoInterface;

import java.util.List;

import entity.Customer;

public interface CustomerDAO {
    int addCustomer(Customer customer);
    int updateCustomer(Customer customer);
    int deleteCustomer(int userId);
    Customer getCustomerById(int userId);
    List<Customer> getAllCustomers();
}
