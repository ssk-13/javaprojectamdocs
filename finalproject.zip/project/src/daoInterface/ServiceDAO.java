package daoInterface;

import java.util.List;

import entity.Serviceeee;


public interface ServiceDAO {
    int addService(Serviceeee service);
    int updateService(Serviceeee service);
    int deleteService(int serviceId);
    Serviceeee getServiceById(int serviceId);
    List<Serviceeee> getAllServices();
}
