package serviceImplementations;
import java.util.List;

import daoInterface.CustomerDAO;
import entity.Customer;
import serviceInterfaces.CustomerService;

public class CustomerServiceImpl implements CustomerService {
    private CustomerDAO customerDAO;

    public CustomerServiceImpl(CustomerDAO customerDAO) {
        this.customerDAO = customerDAO;
    }

    @Override
    public int addCustomer(Customer customer) {
        return customerDAO.addCustomer(customer);
    }

    @Override
    public int updateCustomer(Customer customer) {
        return customerDAO.updateCustomer(customer);
    }

    @Override
    public int deleteCustomer(int userId) {
        return customerDAO.deleteCustomer(userId);
    }

    @Override
    public Customer getCustomerById(int userId) {
        return customerDAO.getCustomerById(userId);
    }

    @Override
    public List<Customer> getAllCustomers() {
        return customerDAO.getAllCustomers();
    }
}
