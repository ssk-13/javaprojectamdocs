package serviceImplementations;
import daoInterface.TechnicianDAO;
import entity.Technician;
import serviceInterfaces.TechnicianService;

import java.util.List;

public class TechnicianServiceImpl implements TechnicianService {

    private TechnicianDAO technicianDAO;

    public TechnicianServiceImpl(TechnicianDAO technicianDAO) {
        this.technicianDAO = technicianDAO;
    }

    @Override
    public int addTechnician(Technician technician) {
        return technicianDAO.addTechnician(technician);
    }

    @Override
    public int updateTechnician(Technician technician) {
        return technicianDAO.updateTechnician(technician);
    }

    @Override
    public int deleteTechnician(int technicianId) {
        return technicianDAO.deleteTechnician(technicianId);
    }

    @Override
    public Technician getTechnicianById(int technicianId) {
        return technicianDAO.getTechnicianById(technicianId);
    }

    @Override
    public List<Technician> getAllTechnicians() {
        return technicianDAO.getAllTechnicians();
    }
}
