package serviceImplementations;

import java.util.List;

import daoInterface.ServiceDAO;
import entity.Serviceeee;
import serviceInterfaces.ServiceService;

public class ServiceServiceImpl implements ServiceService {
    private ServiceDAO serviceDAO;

    public ServiceServiceImpl(ServiceDAO serviceDAO) {
        this.serviceDAO = serviceDAO;
    }

    @Override
    public int addService(Serviceeee service) {
        return serviceDAO.addService(service);
    }

    @Override
    public int updateService(Serviceeee service) {
        return serviceDAO.updateService(service);
    }

    @Override
    public int deleteService(int serviceId) {
        return serviceDAO.deleteService(serviceId);
    }

    @Override
    public Serviceeee getServiceById(int serviceId) {
        return serviceDAO.getServiceById(serviceId);
    }

    @Override
    public List<Serviceeee> getAllServices() {
        return serviceDAO.getAllServices();
    }
}
