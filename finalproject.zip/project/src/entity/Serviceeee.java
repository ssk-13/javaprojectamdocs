package entity;

public class Serviceeee {

	private int serviceId;
	    private String description;
	    private double charges;
		public int getServiceId() {
			return serviceId;
		}
		public void setServiceId(int serviceId) {
			this.serviceId = serviceId;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public double getCharges() {
			return charges;
		}
		public void setCharges(double charges) {
			this.charges = charges;
		}

}
