package Main;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import daoImplementations.AppointmentDAOImpl;
import daoImplementations.CustomerDAOImpl;
import daoImplementations.ServiceDAOImpl;
import daoImplementations.TechnicianDAOImpl;
import daoInterface.AppointmentDAO;
import daoInterface.CustomerDAO;
import daoInterface.ServiceDAO;
import daoInterface.TechnicianDAO;
import entity.Appointment;
import entity.Customer;
import entity.Serviceeee;
import entity.Technician;
import serviceImplementations.AppointmentServiceImpl;
import serviceImplementations.CustomerServiceImpl;
import serviceImplementations.ServiceServiceImpl;
import serviceImplementations.TechnicianServiceImpl;
import serviceInterfaces.AppointmentService;
import serviceInterfaces.CustomerService;
import serviceInterfaces.ServiceService;
import serviceInterfaces.TechnicianService;

public class Main {
	  public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Initialize services and DAOs
	        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/techapp", "root", "root")) {
	            // Replace "username" and "password" with your MySQL username and password.

	            CustomerDAO customerDAO = new CustomerDAOImpl(connection);
	            CustomerService customerService = new CustomerServiceImpl(customerDAO);
	            
	            TechnicianDAO technicianDAO = new TechnicianDAOImpl(connection);
	            TechnicianService technicianService = new TechnicianServiceImpl(technicianDAO);
	            
	            
	            AppointmentDAO appointmentDAO = new AppointmentDAOImpl(connection);
	            AppointmentService appointmentService = new AppointmentServiceImpl(appointmentDAO);
	            
	            
	            ServiceDAO serviceDAO = new ServiceDAOImpl(connection);
	            ServiceService serviceService = new ServiceServiceImpl(serviceDAO);


	            // Add similar initialization for other services and DAOs


            while (true) {
                System.out.println("1. Customer");
                System.out.println("2. Technician");
                System.out.println("3. Appointment");
                System.out.println("4. Service");
                System.out.println("5. Exit");

                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        CustomerMenu.run(customerService, scanner);
                        break;
                    case 2:
                        TechnicianMenu.run(technicianService, scanner);

                        break;
                    case 3:
                    	 AppointmentMenu.run(appointmentService,scanner);
                        break;
                    case 4:
                    	 ServiceMenu.run(serviceService,scanner);
                        break;
                    case 5:
                        System.out.println("Exiting the application. Goodbye!");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error connecting to the database. Exiting the application.");
        }
    }
}

class CustomerMenu {
    public static void run(CustomerService customerService, Scanner scanner) {
        while (true) {
            System.out.println("1. Add Customer");
            System.out.println("2. Update Customer");
            System.out.println("3. Delete Customer");
            System.out.println("4. View Single Customer");
            System.out.println("5. View All Customers");
            System.out.println("6. Back to Main Menu");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addCustomer(customerService, scanner);
                    break;
                case 2:
                    updateCustomer(customerService, scanner);
                    break;
                case 3:
                    deleteCustomer(customerService, scanner);
                    break;
                case 4:
                    viewSingleCustomer(customerService, scanner);
                    break;
                case 5:
                    viewAllCustomers(customerService);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addCustomer(CustomerService customerService, Scanner scanner) {
        // Example: Prompt user for customer details and call customerService.addCustomer
        System.out.print("Enter User Name: ");
        String userName = scanner.next();
        System.out.print("Enter Password: ");
        String password = scanner.next();
        System.out.print("Enter Name: ");
        String name = scanner.next();
        System.out.print("Enter Address: ");
        String address = scanner.next();
        System.out.print("Enter Contact No: ");
        String contactNo = scanner.next();

        Customer newCustomer = new Customer();
        newCustomer.setUserName(userName);
        newCustomer.setPassword(password);
        newCustomer.setName(name);
        newCustomer.setAddress(address);
        newCustomer.setContactNo(contactNo);

        int rowsAffected = customerService.addCustomer(newCustomer);
        System.out.println(rowsAffected + " customer(s) added.");
    }

    private static void updateCustomer(CustomerService customerService, Scanner scanner) {
        // Example: Prompt user for customer details and call customerService.updateCustomer
        System.out.print("Enter User ID to update: ");
        int userId = scanner.nextInt();
        Customer existingCustomer = customerService.getCustomerById(userId);

        if (existingCustomer != null) {
            System.out.print("Enter User Name (Enter to keep the same: ");
            String userName = scanner.nextLine();
            if (!userName.isEmpty()) {
                existingCustomer.setUserName(userName);
            }

            System.out.print("Enter Password (Enter to keep the same: ");
            String password = scanner.nextLine();
            if (!password.isEmpty()) {
                existingCustomer.setPassword(password);
            }

            System.out.print("Enter Name (Enter to keep the same: ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                existingCustomer.setName(name);
            }

            System.out.print("Enter Address (Enter to keep the same: ");
            String address = scanner.nextLine();
            if (!address.isEmpty()) {
                existingCustomer.setAddress(address);
            }

            System.out.print("Enter Contact No (Enter to keep the same: ");
            String contactNo = scanner.nextLine();
            if (!contactNo.isEmpty()) {
                existingCustomer.setContactNo(contactNo);
            }

            int rowsAffected = customerService.updateCustomer(existingCustomer);
            System.out.println(rowsAffected + " customer(s) updated.");
        } else {
            System.out.println("Customer with User ID " + userId + " not found.");
        }
    }
    
    

    private static void deleteCustomer(CustomerService customerService, Scanner scanner) {
        // Example: Prompt user for customer ID and call customerService.deleteCustomer
        System.out.print("Enter User ID to delete: ");
        int userId = scanner.nextInt();

        int rowsAffected = customerService.deleteCustomer(userId);
        System.out.println(rowsAffected + " customer(s) deleted.");
    }

    private static void viewSingleCustomer(CustomerService customerService, Scanner scanner) {
        // Example: Prompt user for customer ID and call customerService.getCustomerById
        System.out.print("Enter User ID to view: ");
        int userId = scanner.nextInt();

        Customer customer = customerService.getCustomerById(userId);
        if (customer != null) {
            System.out.println("User ID: " + customer.getUserId());
            System.out.println("User Name: " + customer.getUserName());
            System.out.println("Password: " + customer.getPassword());
            System.out.println("Name: " + customer.getName());
            System.out.println("Address: " + customer.getAddress());
            System.out.println("Contact No: " + customer.getContactNo());
        } else {
            System.out.println("Customer with User ID " + userId + " not found.");
        }
    }

    private static void viewAllCustomers(CustomerService customerService) {
        // Example: Call customerService.getAllCustomers and display the list
        List<Customer> customers = customerService.getAllCustomers();

        if (customers.isEmpty()) {
            System.out.println("No customers found.");
        } else {
            System.out.println("List of Customers:");
            for (Customer customer : customers) {
                System.out.println("User ID: " + customer.getUserId());
                System.out.println("User Name: " + customer.getUserName());
                System.out.println("Password: " + customer.getPassword());
                System.out.println("Name: " + customer.getName());
                System.out.println("Address: " + customer.getAddress());
                System.out.println("Contact No: " + customer.getContactNo());
                System.out.println("---------------------------");
            }
        }
    }
}
class TechnicianMenu {
    public static void run(TechnicianService technicianService, Scanner scanner) {
        while (true) {
            System.out.println("1. Add Technician");
            System.out.println("2. Update Technician");
            System.out.println("3. Delete Technician");
            System.out.println("4. View Single Technician");
            System.out.println("5. View All Technicians");
            System.out.println("6. Back to Main Menu");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addTechnician(technicianService, scanner);
                    break;
                case 2:
                    updateTechnician(technicianService, scanner);
                    break;
                case 3:
                    deleteTechnician(technicianService, scanner);
                    break;
                case 4:
                    viewSingleTechnician(technicianService, scanner);
                    break;
                case 5:
                    viewAllTechnicians(technicianService);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addTechnician(TechnicianService technicianService, Scanner scanner) {
        // Example: Prompt user for technician details and call technicianService.addTechnician
        System.out.print("Enter Name: ");
        String name = scanner.next();
        System.out.print("Enter Address: ");
        String address = scanner.next();
        System.out.print("Enter Contact No: ");
        String contactNo = scanner.next();

        Technician newTechnician = new Technician();
        newTechnician.setName(name);
        newTechnician.setAddress(address);
        newTechnician.setContactNo(contactNo);

        int rowsAffected = technicianService.addTechnician(newTechnician);
        System.out.println(rowsAffected + " technician(s) added.");
    }

    private static void updateTechnician(TechnicianService technicianService, Scanner scanner) {
        // Example: Prompt user for technician details and call technicianService.updateTechnician
        System.out.print("Enter Technician ID to update: ");
        int technicianId = scanner.nextInt();
        Technician existingTechnician = technicianService.getTechnicianById(technicianId);

        if (existingTechnician != null) {
            System.out.print("Enter Name (Enter to keep the same: ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                existingTechnician.setName(name);
            }

            System.out.print("Enter Address (Enter to keep the same: ");
            String address = scanner.nextLine();
            if (!address.isEmpty()) {
                existingTechnician.setAddress(address);
            }

            System.out.print("Enter Contact No (Enter to keep the same: ");
            String contactNo = scanner.nextLine();
            if (!contactNo.isEmpty()) {
                existingTechnician.setContactNo(contactNo);
            }

            int rowsAffected = technicianService.updateTechnician(existingTechnician);
            System.out.println(rowsAffected + " technician(s) updated.");
        } else {
            System.out.println("Technician with ID " + technicianId + " not found.");
        }
    }

    private static void deleteTechnician(TechnicianService technicianService, Scanner scanner) {
        // Example: Prompt user for technician ID and call technicianService.deleteTechnician
        System.out.print("Enter Technician ID to delete: ");
        int technicianId = scanner.nextInt();

        int rowsAffected = technicianService.deleteTechnician(technicianId);
        System.out.println(rowsAffected + " technician(s) deleted.");
    }

    private static void viewSingleTechnician(TechnicianService technicianService, Scanner scanner) {
        // Example: Prompt user for technician ID and call technicianService.getTechnicianById
        System.out.print("Enter Technician ID to view: ");
        int technicianId = scanner.nextInt();

        Technician technician = technicianService.getTechnicianById(technicianId);
        if (technician != null) {
            System.out.println("Technician ID: " + technician.getTechnicianId());
            System.out.println("Name: " + technician.getName());
            System.out.println("Address: " + technician.getAddress());
            System.out.println("Contact No: " + technician.getContactNo());
        } else {
            System.out.println("Technician with ID " + technicianId + " not found.");
        }
    }

    private static void viewAllTechnicians(TechnicianService technicianService) {
        // Example: Call technicianService.getAllTechnicians and display the list
        List<Technician> technicians = technicianService.getAllTechnicians();

        if (technicians.isEmpty()) {
            System.out.println("No technicians found.");
        } else {
            System.out.println("List of Technicians:");
            for (Technician technician : technicians) {
                System.out.println("Technician ID: " + technician.getTechnicianId());
                System.out.println("Name: " + technician.getName());
                System.out.println("Address: " + technician.getAddress());
                System.out.println("Contact No: " + technician.getContactNo());
                System.out.println("---------------------------");
            }
        }
    }
}

class AppointmentMenu {

    public static void run(AppointmentService appointmentService, Scanner scanner) {
        while (true) {
            System.out.println("1. Book an Appointment");
            System.out.println("2. Update Appointment");
            System.out.println("3. Cancel Appointment");
            System.out.println("4. View Single Appointment");
            System.out.println("5. View All Appointments");
            System.out.println("6. Back to Main Menu");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addAppointment(appointmentService, scanner);
                    break;
                case 2:
                    updateAppointment(appointmentService, scanner);
                    break;
                case 3:
                    deleteAppointment(appointmentService, scanner);
                    break;
                case 4:
                	getAppointmentById(appointmentService, scanner);
                    break;
                case 5:
                	getAllAppointments(appointmentService);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addAppointment(AppointmentService appointmentService, Scanner scanner) {
        // Example: Prompt user for appointment details and call appointmentService.bookAppointment
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter Technician ID: ");
        int technicianId = scanner.nextInt();
        System.out.print("Enter Service ID: ");
        int serviceId = scanner.nextInt();

        Appointment newAppointment = new Appointment();
        newAppointment.setUserId(userId);
        newAppointment.setTechnicianId(technicianId);
        newAppointment.setServiceId(serviceId);

        int rowsAffected = appointmentService.addAppointment(newAppointment);
        System.out.println(rowsAffected + " appointment(s) booked.");
    }

    private static void updateAppointment(AppointmentService appointmentService, Scanner scanner) {
        // Example: Prompt user for appointment details and call appointmentService.updateAppointment
        System.out.print("Enter Appointment ID to update: ");
        int appointmentId = scanner.nextInt();
        Appointment existingAppointment = appointmentService.getAppointmentById(appointmentId);

        if (existingAppointment != null) {
            System.out.print("Enter User ID (Enter to keep the same): ");
            int userId = scanner.nextInt();
            if (userId > 0) {
                existingAppointment.setUserId(userId);
            }

            System.out.print("Enter Technician ID (Enter to keep the same): ");
            int technicianId = scanner.nextInt();
            if (technicianId > 0) {
                existingAppointment.setTechnicianId(technicianId);
            }

            System.out.print("Enter Service ID (Enter to keep the same): ");
            int serviceId = scanner.nextInt();
            if (serviceId > 0) {
                existingAppointment.setServiceId(serviceId);
            }

            int rowsAffected = appointmentService.updateAppointment(existingAppointment);
            System.out.println(rowsAffected + " appointment(s) updated.");
        } else {
            System.out.println("Appointment with ID " + appointmentId + " not found.");
        }
    }

    private static void deleteAppointment(AppointmentService appointmentService, Scanner scanner) {
        // Example: Prompt user for appointment ID and call appointmentService.cancelAppointment
        System.out.print("Enter Appointment ID to cancel: ");
        int appointmentId = scanner.nextInt();

        int rowsAffected = appointmentService.deleteAppointment(appointmentId);
        System.out.println(rowsAffected + " appointment(s) canceled.");
    }

    private static void getAppointmentById(AppointmentService appointmentService, Scanner scanner) {
        // Example: Prompt user for appointment ID and call appointmentService.getAppointmentById
        System.out.print("Enter Appointment ID to view: ");
        int appointmentId = scanner.nextInt();

        Appointment appointment = appointmentService.getAppointmentById(appointmentId);
        if (appointment != null) {
            System.out.println("Appointment ID: " + appointment.getAppointmentId());
            System.out.println("User ID: " + appointment.getUserId());
            System.out.println("Technician ID: " + appointment.getTechnicianId());
            System.out.println("Service ID: " + appointment.getServiceId());
        } else {
            System.out.println("Appointment with ID " + appointmentId + " not found.");
        }
    }

    private static void getAllAppointments(AppointmentService appointmentService) {
        // Example: Call appointmentService.getAllAppointments and display the list
        List<Appointment> appointments = appointmentService.getAllAppointments();

        if (appointments.isEmpty()) {
            System.out.println("No appointments found.");
        } else {
            System.out.println("List of Appointments:");
            for (Appointment appointment : appointments) {
                System.out.println("Appointment ID: " + appointment.getAppointmentId());
                System.out.println("User ID: " + appointment.getUserId());
                System.out.println("Technician ID: " + appointment.getTechnicianId());
                System.out.println("Service ID: " + appointment.getServiceId());
                System.out.println("---------------------------");
            }
        }
    }
}

class ServiceMenu {

    public static void run(ServiceService serviceService, Scanner scanner) {
        while (true) {
            System.out.println("1. Add Service");
            System.out.println("2. Update Service");
            System.out.println("3. Delete Service");
            System.out.println("4. View Single Service");
            System.out.println("5. View All Services");
            System.out.println("6. Back to Main Menu");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addService(serviceService, scanner);
                    break;
                case 2:
                    updateService(serviceService, scanner);
                    break;
                case 3:
                    deleteService(serviceService, scanner);
                    break;
                case 4:
                    getServiceById(serviceService, scanner);
                    break;
                case 5:
                    getAllServices(serviceService);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addService(ServiceService serviceService, Scanner scanner) {
        // Example: Prompt user for service details and call serviceService.addService
        System.out.print("Enter Description: ");
        String description = scanner.next();
        System.out.print("Enter Charges: ");
        double charges = scanner.nextDouble();

        Serviceeee newService = new Serviceeee();
        newService.setDescription(description);
        newService.setCharges(charges);

        int rowsAffected = serviceService.addService(newService);
        System.out.println(rowsAffected + " service(s) added.");
    }

    private static void updateService(ServiceService serviceService, Scanner scanner) {
        // Example: Prompt user for service details and call serviceService.updateService
        System.out.print("Enter Service ID to update: ");
        int serviceId = scanner.nextInt();
        Serviceeee existingService = serviceService.getServiceById(serviceId);

        if (existingService != null) {
            System.out.print("Enter Description (Enter to keep the same): ");
            String description = scanner.nextLine();
            if (!description.isEmpty()) {
                existingService.setDescription(description);
            }

            System.out.print("Enter Charges (Enter to keep the same): ");
            double charges = scanner.nextDouble();
            existingService.setCharges(charges);

            int rowsAffected = serviceService.updateService(existingService);
            System.out.println(rowsAffected + " service(s) updated.");
        } else {
            System.out.println("Service with ID " + serviceId + " not found.");
        }
    }

    private static void deleteService(ServiceService serviceService, Scanner scanner) {
        // Example: Prompt user for service ID and call serviceService.deleteService
        System.out.print("Enter Service ID to delete: ");
        int serviceId = scanner.nextInt();

        int rowsAffected = serviceService.deleteService(serviceId);
        System.out.println(rowsAffected + " service(s) deleted.");
    }

    private static void getServiceById(ServiceService serviceService, Scanner scanner) {
        // Example: Prompt user for service ID and call serviceService.getServiceById
        System.out.print("Enter Service ID to view: ");
        int serviceId = scanner.nextInt();

        Serviceeee service = serviceService.getServiceById(serviceId);
        if (service != null) {
            System.out.println("Service ID: " + service.getServiceId());
            System.out.println("Description: " + service.getDescription());
            System.out.println("Charges: " + service.getCharges());
        } else {
            System.out.println("Service with ID " + serviceId + " not found.");
        }
    }

    private static void getAllServices(ServiceService serviceService) {
        // Example: Call serviceService.getAllServices and display the list
        List<Serviceeee> services = serviceService.getAllServices();

        if (services.isEmpty()) {
            System.out.println("No services found.");
        } else {
            System.out.println("List of Services:");
            for (Serviceeee service : services) {
                System.out.println("Service ID: " + service.getServiceId());
                System.out.println("Description: " + service.getDescription());
                System.out.println("Charges: " + service.getCharges());
                System.out.println("---------------------------");
            }
        }
    }
}
