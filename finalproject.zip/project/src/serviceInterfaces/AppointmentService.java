package serviceInterfaces;
import java.util.List;

import entity.Appointment;

public interface AppointmentService {
    int addAppointment(Appointment appointment);
    int updateAppointment(Appointment appointment);
    int deleteAppointment(int appointmentId);
    Appointment getAppointmentById(int appointmentId);
    List<Appointment> getAllAppointments();
}
