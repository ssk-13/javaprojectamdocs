package serviceInterfaces;
import java.util.List;

import entity.Customer;

public interface CustomerService {
    int addCustomer(Customer customer);
    int updateCustomer(Customer customer);
    int deleteCustomer(int userId);
    Customer getCustomerById(int userId);
    List<Customer> getAllCustomers();
}
