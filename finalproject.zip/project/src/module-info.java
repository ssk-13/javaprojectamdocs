/**
 * 
 */
/**
 * @author shubh
 *
 */
module project {
	requires java.sql;
}