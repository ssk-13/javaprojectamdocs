package daoImplementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import daoInterface.AppointmentDAO;
import entity.Appointment;

public  class AppointmentDAOImpl implements AppointmentDAO {

    private static final String INSERT_APPOINTMENT = "INSERT INTO appointment (User_id, Technician_id, Service_id) VALUES (?, ?, ?)";
    private static final String UPDATE_APPOINTMENT = "UPDATE appointment SET User_id = ?, Technician_id = ?, Service_id = ? WHERE Appointment_id = ?";
    private static final String DELETE_APPOINTMENT = "DELETE FROM appointment WHERE Appointment_id = ?";
    private static final String SELECT_APPOINTMENT_BY_ID = "SELECT * FROM appointment WHERE Appointment_id = ?";
    private static final String SELECT_ALL_APPOINTMENTS = "SELECT * FROM appointment";

    private Connection connection;

    public AppointmentDAOImpl(Connection connection) {
        this.connection = connection;
    }

    public int addAppointment(Appointment appointment) {
        try (PreparedStatement statement = connection.prepareStatement(INSERT_APPOINTMENT)) {
            statement.setInt(1, appointment.getUserId());
            statement.setInt(2, appointment.getTechnicianId());
            statement.setInt(3, appointment.getServiceId());

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    public int updateAppointment(Appointment appointment) {
        try (PreparedStatement statement = connection.prepareStatement(UPDATE_APPOINTMENT)) {
            statement.setInt(1, appointment.getUserId());
            statement.setInt(2, appointment.getTechnicianId());
            statement.setInt(3, appointment.getServiceId());
            statement.setInt(4, appointment.getAppointmentId());

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    public int deleteAppointment(int appointmentId) {
        try (PreparedStatement statement = connection.prepareStatement(DELETE_APPOINTMENT)) {
            statement.setInt(1, appointmentId);

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    public Appointment getAppointmentById(int appointmentId) {
        try (PreparedStatement statement = connection.prepareStatement(SELECT_APPOINTMENT_BY_ID)) {
            statement.setInt(1, appointmentId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractAppointmentFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return null;
    }

    public List<Appointment> getAllAppointments() {
        List<Appointment> appointments = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(SELECT_ALL_APPOINTMENTS)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Appointment appointment = extractAppointmentFromResultSet(resultSet);
                appointments.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return appointments;
    }

    private Appointment extractAppointmentFromResultSet(ResultSet resultSet) throws SQLException {
        Appointment appointment = new Appointment();
        appointment.setAppointmentId(resultSet.getInt("Appointment_id"));
        appointment.setUserId(resultSet.getInt("User_id"));
        appointment.setTechnicianId(resultSet.getInt("Technician_id"));
        appointment.setServiceId(resultSet.getInt("Service_id"));
        return appointment;
    }
}
