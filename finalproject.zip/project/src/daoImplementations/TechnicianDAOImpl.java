package daoImplementations;

import daoInterface.TechnicianDAO;
import entity.Technician;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TechnicianDAOImpl implements TechnicianDAO {

    private static final String INSERT_TECHNICIAN = "INSERT INTO Technician (Name, Address, Contact_no) VALUES (?, ?, ?)";
    private static final String UPDATE_TECHNICIAN = "UPDATE Technician SET Name = ?, Address = ?, Contact_no = ? WHERE Technician_id = ?";
    private static final String DELETE_TECHNICIAN = "DELETE FROM Technician WHERE Technician_id = ?";
    private static final String SELECT_TECHNICIAN_BY_ID = "SELECT * FROM Technician WHERE Technician_id = ?";
    private static final String SELECT_ALL_TECHNICIANS = "SELECT * FROM Technician";

    private Connection connection;

    public TechnicianDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public int addTechnician(Technician technician) {
        try (PreparedStatement statement = connection.prepareStatement(INSERT_TECHNICIAN)) {
            statement.setString(1, technician.getName());
            statement.setString(2, technician.getAddress());
            statement.setString(3, technician.getContactNo());

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    @Override
    public int updateTechnician(Technician technician) {
        try (PreparedStatement statement = connection.prepareStatement(UPDATE_TECHNICIAN)) {
            statement.setString(1, technician.getName());
            statement.setString(2, technician.getAddress());
            statement.setString(3, technician.getContactNo());
            statement.setInt(4, technician.getTechnicianId());

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    @Override
    public int deleteTechnician(int technicianId) {
        try (PreparedStatement statement = connection.prepareStatement(DELETE_TECHNICIAN)) {
            statement.setInt(1, technicianId);

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    @Override
    public Technician getTechnicianById(int technicianId) {
        try (PreparedStatement statement = connection.prepareStatement(SELECT_TECHNICIAN_BY_ID)) {
            statement.setInt(1, technicianId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractTechnicianFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return null;
    }

    @Override
    public List<Technician> getAllTechnicians() {
        List<Technician> technicians = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(SELECT_ALL_TECHNICIANS)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Technician technician = extractTechnicianFromResultSet(resultSet);
                technicians.add(technician);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return technicians;
    }

    private Technician extractTechnicianFromResultSet(ResultSet resultSet) throws SQLException {
        Technician technician = new Technician();
        technician.setTechnicianId(resultSet.getInt("Technician_id"));
        technician.setName(resultSet.getString("Name"));
        technician.setAddress(resultSet.getString("Address"));
        technician.setContactNo(resultSet.getString("Contact_no"));
        return technician;
    }
}
