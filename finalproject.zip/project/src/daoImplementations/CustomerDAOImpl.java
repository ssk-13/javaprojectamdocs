package daoImplementations;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import daoInterface.CustomerDAO;
import entity.Customer;

public  class CustomerDAOImpl implements CustomerDAO {

    private static final String INSERT_CUSTOMER = "INSERT INTO customer (User_name, password, Name, Address, Contact_no) VALUES (?, ?, ?, ?, ?)";
    private static final String UPDATE_CUSTOMER = "UPDATE customer SET User_name = ?, password = ?, Name = ?, Address = ?, Contact_no = ? WHERE User_id = ?";
    private static final String DELETE_CUSTOMER = "DELETE FROM customer WHERE User_id = ?";
    private static final String SELECT_CUSTOMER_BY_ID = "SELECT * FROM customer WHERE User_id = ?";
    private static final String SELECT_ALL_CUSTOMERS = "SELECT * FROM customer";

    private Connection connection;

    public CustomerDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public int addCustomer(Customer customer) {
        try (PreparedStatement statement = connection.prepareStatement(INSERT_CUSTOMER)) {
            statement.setString(1, customer.getUserName());
            statement.setString(2, customer.getPassword());
            statement.setString(3, customer.getName());
            statement.setString(4, customer.getAddress());
            statement.setString(5, customer.getContactNo());

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    @Override
    public int updateCustomer(Customer customer) {
        try (PreparedStatement statement = connection.prepareStatement(UPDATE_CUSTOMER)) {
            statement.setString(1, customer.getUserName());
            statement.setString(2, customer.getPassword());
            statement.setString(3, customer.getName());
            statement.setString(4, customer.getAddress());
            statement.setString(5, customer.getContactNo());
            statement.setInt(6, customer.getUserId());

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    @Override
    public int deleteCustomer(int userId) {
        try (PreparedStatement statement = connection.prepareStatement(DELETE_CUSTOMER)) {
            statement.setInt(1, userId);

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    @Override
    public Customer getCustomerById(int userId) {
        try (PreparedStatement statement = connection.prepareStatement(SELECT_CUSTOMER_BY_ID)) {
            statement.setInt(1, userId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractCustomerFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return null;
    }

    @Override
    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(SELECT_ALL_CUSTOMERS)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Customer customer = extractCustomerFromResultSet(resultSet);
                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return customers;
    }

    private Customer extractCustomerFromResultSet(ResultSet resultSet) throws SQLException {
        Customer customer = new Customer();
        customer.setUserId(resultSet.getInt("User_id"));
        customer.setUserName(resultSet.getString("User_name"));
        customer.setPassword(resultSet.getString("password"));
        customer.setName(resultSet.getString("Name"));
        customer.setAddress(resultSet.getString("Address"));
        customer.setContactNo(resultSet.getString("Contact_no"));
        return customer;
    }
}
