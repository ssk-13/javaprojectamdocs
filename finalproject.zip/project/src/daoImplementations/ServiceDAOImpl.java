package daoImplementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import daoInterface.ServiceDAO;
import entity.Serviceeee; // Assuming your Service class is in the provider package

public class ServiceDAOImpl implements ServiceDAO {

    private static final String INSERT_SERVICE = "INSERT INTO service (description, charges) VALUES (?, ?)";
    private static final String UPDATE_SERVICE = "UPDATE service SET description = ?, charges = ? WHERE service_id = ?";
    private static final String DELETE_SERVICE = "DELETE FROM service WHERE service_id = ?";
    private static final String SELECT_SERVICE_BY_ID = "SELECT * FROM service WHERE service_id = ?";
    private static final String SELECT_ALL_SERVICES = "SELECT * FROM service";

    private Connection connection;

    public ServiceDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public int addService(Serviceeee service) {
        try (PreparedStatement statement = connection.prepareStatement(INSERT_SERVICE)) {
            statement.setString(1, service.getDescription());
            statement.setDouble(2, service.getCharges());

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    @Override
    public int updateService(Serviceeee service) {
        try (PreparedStatement statement = connection.prepareStatement(UPDATE_SERVICE)) {
            statement.setString(1, service.getDescription());
            statement.setDouble(2, service.getCharges());
            statement.setInt(3, service.getServiceId());

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    @Override
    public int deleteService(int serviceId) {
        try (PreparedStatement statement = connection.prepareStatement(DELETE_SERVICE)) {
            statement.setInt(1, serviceId);

            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return 0;
        }
    }

    @Override
    public Serviceeee getServiceById(int serviceId) {
        try (PreparedStatement statement = connection.prepareStatement(SELECT_SERVICE_BY_ID)) {
            statement.setInt(1, serviceId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractServiceFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return null;
    }

    @Override
    public List<Serviceeee> getAllServices() {
        List<Serviceeee> services = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(SELECT_ALL_SERVICES)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Serviceeee service = extractServiceFromResultSet(resultSet);
                services.add(service);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return services;
    }

    private Serviceeee extractServiceFromResultSet(ResultSet resultSet) throws SQLException {
        Serviceeee service = new Serviceeee();
        service.setServiceId(resultSet.getInt("service_id"));
        service.setDescription(resultSet.getString("description"));
        service.setCharges(resultSet.getDouble("charges"));
        return service;
    }
}
